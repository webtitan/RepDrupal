<input type="text" name="search_block_form" value="Search" class="search-form" onblur="if(this.value=='') this.value='Search'" onfocus="if(this.value =='Search' ) this.value=''"/>
<input type="submit" class="button-search" name="op" value="" />
	
<?php print($search['hidden']); ?>