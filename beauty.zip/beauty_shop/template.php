<?php
function beauty_shop_preprocess_html(&$variables) {
  drupal_add_js('http://html5shim.googlecode.com/svn/trunk/html5.js', 'external');
}
?>